package assistedPractice;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Filecreating {

    public static void main(String[] args) {
        File file = new File("newFile.txt");

        //Create the file
        try {
            if (file.createNewFile()) {
                System.out.println("New Text File is created!");
            } else {
                System.out.println("File already exists.");
            }
            //Write Content
            FileWriter writer = new FileWriter(file);
            writer.write("Test data");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
