import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GreetingComponent } from './greeting/greeting.component';
import { FormsModule } from '@angular/forms';
import { TemplateformexampleComponent } from './templateformexample/templateformexample.component';
import { ValidtemplateformComponent } from './validtemplateform/validtemplateform.component';
import { ReactiveformexampleComponent } from './reactiveformexample/reactiveformexample.component';
@NgModule({
  declarations: [
    AppComponent,
    GreetingComponent,
    TemplateformexampleComponent,
    ValidtemplateformComponent,
    ReactiveformexampleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
