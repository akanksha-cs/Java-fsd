package DataStructure;

public class fourthsmallest {
	public static void main(String args[]) {
		int arr[] = new int[] {85,55,99,40,51};
		int min=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]<min) {
				min=arr[i];
			}
		}
		System.out.println(""+min);
	}
	

}
