package com.businesslogic;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConfig {
	
	public static Connection getConnection(Properties props) {
		
		Connection  conn=null;
		
		
		
		try {
			//load the driver
			Class.forName(props.getProperty("com.mysql.cj.jdbc.Driver"));
			
			
			conn= DriverManager.getConnection(props.getProperty("jdbc:mysql://localhost:3306"),
						props.getProperty(" ecommerce2"),props.getProperty("Aavira2425@@"));
			 
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return conn;
	}

}