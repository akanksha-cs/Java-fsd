import { Component, OnInit } from '@angular/core';
import { UsersService } from './users.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  pageTitle:string = "HTTP Services in Angular";
  users:any[]=[];
  constructor(private userService:UsersService){

  }
  ngOnInit() {
   this.userService.getAllUsers().subscribe((data)=>{
    this.users = data;
   });
  }
 
}
