import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heros-list',
  templateUrl: './heros-list.component.html',
  styleUrls: ['./heros-list.component.css']
})
export class HerosListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
