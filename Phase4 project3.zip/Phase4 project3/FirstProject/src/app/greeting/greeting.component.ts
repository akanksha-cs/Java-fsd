import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.css']
})
export class GreetingComponent implements OnInit {

  constructor() { }

  @Input()  productList: Array<any>=[];

  ngOnInit(): void {

  }

  name : string ="Akanksha";

isDisabled= false;


  greet(): void{
    alert("Hello All!!!"+this.name);
  }
}



