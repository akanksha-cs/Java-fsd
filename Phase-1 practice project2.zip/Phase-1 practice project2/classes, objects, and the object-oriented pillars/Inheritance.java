package assistedPractice;


import java.io.*;
import java.lang.*;
import java.util.*;
  
class Inheritance {
    public void print_geek()
    {
        System.out.println("Geeks");
    }
}
  
class two extends Inheritance {
    public void print_for() { System.out.println("for"); }
}
// Driver class
public class Main {
    public static void main(String[] args)
    {
        two g = new two();
        g.print_geek();
        g.print_for();
        g.print_geek();
    }
}