package com.example.authentication.services;

import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.authentication.exceptions.UserNotFoundException;
import com.example.authentication.repositories.UserRepository;

@Service
public class LoginService {
	@Autowired
	UserRepository authRepo;
	public User GetUserByName(String name) {
		Optional<User> found = authRepo.findByName(name);
		if(found.isPresent()) return found.get();
		else throw new UserNotFoundException();
	}
public Boolean isValidPassword(String cmp, String actual) {
return ((cmp.equals(actual)) ?  true :  false);	
}
}