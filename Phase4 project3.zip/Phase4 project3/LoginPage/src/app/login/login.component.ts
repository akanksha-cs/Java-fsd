import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
name:string="Akanksha";
  constructor() { }

  ngOnInit(): void {
  }
  username:string="";
  password:string="";
  msg="";
  status:string='error';
  validate(){
    if(this.username=="abc" && this.password=="123"){
      this.status='';
        this.msg="welcome"+this.username;
    }
    else{
      this.msg="Invalid user";
      this.status='error';
    }
    this.username="";
    this.password="";
  }
  greet(): void{
    alert("Hello All!!!"+this.name);
  }
}
